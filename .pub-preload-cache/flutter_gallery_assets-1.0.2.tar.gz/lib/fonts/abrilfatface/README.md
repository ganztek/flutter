Flutter Gallery, Shrine Demo Assets

The AbrilFatface font was downloaded from https://github.com/google/fonts/tree/master/ofl/abrilfatface
