Flutter Gallery, Fortnightly Demo Assets

The Merriweather font was downloaded from https://fonts.google.com/specimen/Merriweather
