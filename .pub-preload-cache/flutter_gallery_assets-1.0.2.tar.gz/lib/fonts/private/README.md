# Private Fonts
These fonts are not intended for reuse or redistribution.

Please see [fonts.google.com](https://fonts.google.com) for options you can use.

## Google Sans is NOT Licensed for Use

Google offers many fonts under open source licenses. __This is not one of them.___

Please see [fonts.google.com](https://fonts.google.com) for options you can use.