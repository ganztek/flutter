Flutter Gallery, Shrine Demo Assets

The Rubik font was downloaded from https://fonts.google.com/specimen/Rubik
