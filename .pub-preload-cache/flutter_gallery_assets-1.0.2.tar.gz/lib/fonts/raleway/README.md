Flutter Gallery, Shrine Demo Assets

The Raleway font was downloaded from https://fonts.google.com/specimen/Raleway
