Flutter Gallery, Fortnightly Demo Assets

The Libre Frankline font was downloaded from https://fonts.google.com/specimen/Libre+Franklin
