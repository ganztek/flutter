# Flutter Gallery Assets

Images, fonts, and videos used in the Flutter Gallery app. See [flutter.dev](https://flutter.dev)

## Origin of Videos

[CC0 1.0 Universal](https://creativecommons.org/publicdomain/zero/1.0/legalcode) videos from:

- https://pixabay.com/en/videos/butterfly-flower-insect-nature-209/
- https://pixabay.com/en/videos/honey-bee-insect-bee-flower-flying-211/mit-macbookpro2:gallery-assets
